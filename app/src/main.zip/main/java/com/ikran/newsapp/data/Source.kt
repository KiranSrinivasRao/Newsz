package com.ikran.newsapp.data

data class Source(
    val id: String?,
    val name: String?
)