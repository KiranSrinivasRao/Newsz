package com.ikran.newsapp.util

class Constants {

    companion object{
        const val NEWS_API_KEY = "015ebaaf8d2b49cbbc1896815fcc1f10"
        const val BASE_URL = "https://newsapi.org/"
    }
}