package com.ikran.newsapp

import android.app.Application

class NewsApp:Application() {
}